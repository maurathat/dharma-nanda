NANDA Town System Fitness Report
========================================
Run:       sim-b41ed837aebc
Scenario:  open (seed 1)
Faults:    none
Agents:    council (dn_council), member-1 (dn_member), member-2 (dn_member), member-3 (dn_member), relay-1 (dn_relay), seller-1 (dn_seller), seller-2 (dn_seller), seller-3 (dn_seller), seller-4 (dn_seller), seller-5 (dn_seller), seller-6 (dn_seller), cheat-1 (dn_seller), inject-1 (dn_seller), spotter-1 (dn_seller), wave-1 (dn_seller), wave-2 (dn_seller), judge-1 (dn_judge), judge-2 (dn_judge), judge-3 (dn_judge), judge-4 (dn_judge), judge-5 (dn_judge), watchtower (dn_watchtower), buyer-1 (dn_buyer), buyer-2 (dn_buyer), buyer-3 (dn_buyer), buyer-4 (dn_buyer), buyer-5 (dn_buyer), buyer-6 (dn_buyer), tester-1 (dn_tester)
Releases:  evaluator lab-0.2.6, nandatown 0.2.0, python 3.13.18
Duration:  16.7 logical seconds, deterministic
Verdict:   PASSED
Rerun:     nandatown run /home/claude/dharma-nanda/scenarios/open.yaml --seed 1

The journey: bring, connect, attempt, disrupt, inspect, improve.

Stages (each one a separate claim with its own failure boundary):
  records_recompute  Passed                [ev-32, ev-93, ev-97, ev-101, ev-105, ev-110, ev-114, ev-118]
                     note: 289 records; 0 do not recompute to the identity they were published under
  lineage_resolves   Passed                [ev-32, ev-93, ev-97, ev-101, ev-105, ev-110, ev-114, ev-118]
                     note: verified=384 failed=0 unresolved=0 malformed=0 cyclic=0
  town_measures      Passed                [ev-32, ev-93, ev-97, ev-101, ev-105, ev-110, ev-114, ev-118]
                     note: trades=96 value=104000 paid=96000 paid_for_bad_work=31000 good_work_refused=0 honest_suspended=0/6 red_trading=5/5 watch_cases=0 pardons=0 rule_changes=0
  ledger_conserved   Passed               money was conserved across every movement [ev-94, ev-98, ev-102, ev-106, ev-122, ev-130, ev-155, ev-160]
                     note: 336000 cents conserved across every movement
  privacy            Not tested           not exercised in this run
                     note: no redaction declared by this scenario

Events recorded: 1540. Intents recorded: 592.
This result applies only to the named agents, releases, scenario, failure, evaluator, and time window.
One run is one scoped observation, not a certificate.
Improve: fix what failed and rerun the same profile.
