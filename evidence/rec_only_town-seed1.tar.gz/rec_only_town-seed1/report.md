NANDA Town System Fitness Report
========================================
Run:       sim-d52e7c9b8a68
Scenario:  rec_only_town (seed 1)
Faults:    none
Agents:    council (dn_council), member-1 (dn_member), member-2 (dn_member), member-3 (dn_member), relay-1 (dn_relay), relay-2 (dn_relay), seller-1 (dn_seller), seller-2 (dn_seller), seller-3 (dn_seller), seller-4 (dn_seller), seller-5 (dn_seller), seller-6 (dn_seller), cheat-1 (dn_seller), inject-1 (dn_seller), spotter-1 (dn_seller), wave-1 (dn_seller), wave-2 (dn_seller), judge-1 (dn_judge), judge-2 (dn_judge), judge-3 (dn_judge), judge-4 (dn_judge), judge-5 (dn_judge), watchtower (dn_watchtower), buyer-1 (dn_buyer), buyer-2 (dn_buyer), buyer-3 (dn_buyer), buyer-4 (dn_buyer), buyer-5 (dn_buyer), buyer-6 (dn_buyer), tester-1 (dn_tester)
Releases:  evaluator lab-0.2.6, nandatown 0.2.0, python 3.13.18
Duration:  16.7 logical seconds, deterministic
Verdict:   PASSED
Rerun:     nandatown run /home/claude/dharma-nanda/scenarios/rec_only_town.yaml --seed 1

The journey: bring, connect, attempt, disrupt, inspect, improve.

Stages (each one a separate claim with its own failure boundary):
  records_recompute  Passed                [ev-34, ev-97, ev-102, ev-107, ev-112, ev-118, ev-123, ev-128]
                     note: 561 records; 0 do not recompute to the identity they were published under
  records_signed     Passed                [ev-34, ev-97, ev-102, ev-107, ev-112, ev-118, ev-123, ev-128]
                     note: valid=561 invalid=0 unsigned=0 (signed by the key registered to the named owner)
  lineage_resolves   Passed                [ev-34, ev-97, ev-102, ev-107, ev-112, ev-118, ev-123, ev-128]
                     note: verified=560 failed=0 unresolved=0 malformed=0 cyclic=0
  town_measures      Passed                [ev-34, ev-97, ev-102, ev-107, ev-112, ev-118, ev-123, ev-128]
                     note: trades=96 value=0 paid=0 paid_for_bad_work=0 good_work_refused=79 honest_suspended=0/6 red_trading=5/5 watch_cases=0 pardons=0 rule_changes=0
  ledger_conserved   Passed               money was conserved across every movement [ev-98, ev-103, ev-108, ev-113, ev-133, ev-143, ev-148, ev-252]
                     note: 336000 cents conserved across every movement
  privacy            Not tested           not exercised in this run
                     note: no redaction declared by this scenario

Events recorded: 3146. Intents recorded: 1024.
This result applies only to the named agents, releases, scenario, failure, evaluator, and time window.
One run is one scoped observation, not a certificate.
Improve: fix what failed and rerun the same profile.
